/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swelab2;
import java.util.*;
import java.sql.*;
public class Swelab2 {

   
    public static void main(String[] args) {
        System.out.println("welcome");
        while(true) {
            System.out.println("1.ADD"+ "\n" + "2.DELETE"+ "\n" + "3.EDIT"+ "\n" + "4.SEARCH BY ROLLNO"
            + "\n" + "5.SHOW BY NAME AND AGE" + "\n" + "6.EXIT");
            Scanner in = new Scanner(System.in);
            int ch;
            ch = in.nextInt();
            switch(ch) {
                case 1:
                    add ob = new add();
                    ob.adddet();
                    break;
                case 2:
                    deletein ob1 = new deletein();
                    ob1.delinfo();
                    break;
                case 3:
                    Edit ob4 = new Edit();
                    ob4.editdet();
                    break;
                case 4:
                    search ob2 = new search();
                    ob2.searchinfo();
                    break;
                case 5:
                    show ob3 = new show();
                    ob3.showinfo();
                    break;
                case 6:
                    System.exit(0);
                default:
                    System.out.println("Wrong choice");
            }
        }
            
        //    this.setVisible(false);
    //        ob.setVisible(true);
            
  
}
}
    

