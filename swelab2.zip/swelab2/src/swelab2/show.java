/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swelab2;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.JOptionPane;


public class show {
    public Connection con;
    public String sql;
    public Statement st;
    public ResultSet rs;
    public int rno;
    public void showinfo(){
      sql = "SELECT * FROM students ORDER BY NAME DESC,AGE DESC";
         try {
              con = Sqlconnect.connectDb();
            if(con!=null)
            {
                System.out.println(sql);
                st= con.prepareStatement(sql);
                rs = st.executeQuery(sql);
              //  System.out.println(rs.getInt(1) + " " + rs.getString(2));
                while(rs.next())
               System.out.println(+rs.getInt(1)+" "+rs.getString(2)+ " " +rs.getString(3) +" "+rs.getString(4) + " " 
                        +rs.getInt(5) + " " +rs.getString(6)+ " " + rs.getFloat(7));
                con.close();
            }
            else
            {
                System.out.println("wrong");
            }
        } catch (SQLException ex) {
            //Logger.getLogger(ward_entry.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }
    }
    
}
