
package swelab2;

import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;


public class Edit {
    public Connection con = null;
    public Statement st;
    public ResultSet rs;
    public String name,fname,addr,mno,sql,a;
    public int age,rno;
    public float cgpa;
    
    public void editdet() {
        System.out.println("Enter Roll no of sudent whose record is to be updated");
        Scanner in = new Scanner(System.in);
        rno = in.nextInt();
        try {
            System.out.println("Edit\n"+"1.Name" + "\n" +"2.Father's Name" + "\n" +
                "3.Address" + "\n" +"4.Age" + "\n" +"5.Mobile No" + "\n" +
                "6.CGPA");
        int ch = in.nextInt();
         con = Sqlconnect.connectDb();
         st = con.createStatement();
        switch(ch) {
            case 1:
                name = in.nextLine();
                sql = "UPDATE students SET Name = '"+name+"' WHERE Rollno = "+rno+"";
                st.executeUpdate(sql);
                break;
            case 2:
                fname = in.nextLine();
                sql = "UPDATE students SET Father_Name = '"+fname+"' WHERE Rollno = "+rno+"";
                st.executeUpdate(sql);
                break;
            case 3:
                addr = in.nextLine();
                sql = "UPDATE students SET Address = '"+addr+"' WHERE Rollno = "+rno+"";
                st.executeUpdate(sql);
                break;
            case 4:
                age = in.nextInt();
                sql = "UPDATE students SET Age = '"+age+"' WHERE Rollno = "+rno+"";
                st.executeUpdate(sql);
                break;
            case 5:
                mno = in.nextLine();
                sql = "UPDATE students SET Mobile_Number  = '"+mno+"' WHERE Rollno = "+rno+"";
                st.executeUpdate(sql);
                break;
            case 6:
                cgpa = in.nextFloat();
                sql = "UPDATE students SET CGPA = '"+cgpa+"' WHERE Rollno = "+rno+"";
                st.executeUpdate(sql);
                break;
            default:
                System.out.println("wrong choice");
         }
        } catch (SQLException ex) {
            //Logger.getLogger(ward_entry.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }
           
    }
          
    
}
