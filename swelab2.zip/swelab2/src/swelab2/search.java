/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swelab2;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.JOptionPane;
public class search {
    public Connection con = null;
    public Statement st;
    public ResultSet rs;
   // public String name,fname,addr,mno,sql,a;
    public int age,rno;
    public float cgpa;
    PreparedStatement pst = null;
    
    public void searchinfo()
    {
         System.out.println("Enter rollno");
         Scanner in = new Scanner(System.in);
         rno = in.nextInt();
         String sql = "SELECT * FROM students WHERE rollno = "+rno+"";
         try {
              con = Sqlconnect.connectDb();
            if(con!=null)
            {
                System.out.println(sql);
                pst= con.prepareStatement(sql);
                rs = pst.executeQuery(sql);
              //  System.out.println(rs.getInt(1) + " " + rs.getString(2));
                while(rs.next())
               System.out.println("RollNo :"+rs.getInt(1)+"\n"+"Name :"+rs.getString(2)+ "\n" 
                        +"Father's Name : "+rs.getString(3) +"\n"+"Address :"+rs.getString(4) + "\n" 
                        +"Age :"+rs.getInt(5) + "\n" +"Mobile No :" +rs.getString(6)+ "\n" +
                        "CGPA :"+rs.getFloat(7));
                con.close();
            }
            else
            {
                System.out.println("wrong");
            }
        } catch (SQLException ex) {
            //Logger.getLogger(ward_entry.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }
   
    }
    
}
