/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swelab2;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class add {
    public Connection con = null;
    public Statement st;
    public ResultSet rs;
    public String name,fname,addr,mno,sql,a;
    public int age,rno;
    public float cgpa;
    
    public void adddet()
    {
        try {
            
            System.out.println("enter details");
        Scanner in = new Scanner(System.in);
         rno = in.nextInt();
         a = in.nextLine();
        name = in.nextLine();
        fname = in.nextLine();
        addr = in.nextLine();
       age = in.nextInt();
       a = in.nextLine();
        mno = in.nextLine();
        cgpa = in.nextFloat();
      //  a = in.nextLine();
        System.out.println("done");
        
        con = Sqlconnect.connectDb();
        if(con!=null) {
        sql = "insert into students values("+rno+",'"+name+"','"+fname+"','"+addr+"',"+age+",'"+mno+"',"+cgpa+")";
        System.out.println(sql);
        st = con.createStatement();
        st.executeUpdate(sql);
        con.close(); }
        else
        {
            System.out.println("wrong");
        }
          
        
        } catch (SQLException ex) {
            //Logger.getLogger(ward_entry.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }
        
    }    
    
   
   
    
    
    
}
