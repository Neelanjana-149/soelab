/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swelab2;
import java.sql.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.JOptionPane;


/**
 *
 * @author Dell
 */
public class deletein {
     public Connection con = null;
    public Statement st;
    public ResultSet rs;
    public int age,rno;
    public float cgpa;
    public void delinfo(){
        System.out.println("Enter rollno");
        Scanner in = new Scanner(System.in);
        rno = in.nextInt();
        String sql = "Delete from students where rollno = "+rno+"";
        try {
            con = Sqlconnect.connectDb();
            if(con!=null)
            {
                st= con.createStatement();
                st.executeUpdate(sql);
                con.close();
            }
            else
            {
                System.out.println("wrong");
            }
        } catch (SQLException ex) {
            //Logger.getLogger(ward_entry.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }
                
            
            
        }
        
}
   
